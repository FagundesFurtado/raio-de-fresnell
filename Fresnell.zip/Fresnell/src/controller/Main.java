package controller;

import java.awt.Point;
import view.Inicializar;
import view.Parametros;

public class Main {

    public static void main(String[] args) {

        Inicializar inicializar = new Inicializar();
        

    }

}
